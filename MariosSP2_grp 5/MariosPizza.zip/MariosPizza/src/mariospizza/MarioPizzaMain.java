package mariospizza;

/**
 * @author Josef, Thor, Hallur og Frederik 
 */

public class MarioPizzaMain {
    public static void main(String[] args) {
        Program program = new Program(); 
    }

}
